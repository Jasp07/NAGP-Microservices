package com.nagarro.microservices.springcloudnetflixeurekaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudNetflixEurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudNetflixEurekaServerApplication.class, args);
	}

}
